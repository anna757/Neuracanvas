const HomePage = () => {
    return (
      <div>
        <h1>Welcome to NeuraCanvas</h1>
        <p>Your one-stop shop for AI-generated images!</p>
      </div>
    );
  };
  
  export default HomePage;
  