import React from 'react';

const CatalogPage = () => {
    return (
        <div>
            <h1>Catalog Page</h1>
        </div>
    );
}

export default CatalogPage;
