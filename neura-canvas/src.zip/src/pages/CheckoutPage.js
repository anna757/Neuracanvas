import React from 'react';

const CheckoutPage = () => {
    return (
        <div>
            <h1>Checkout Page</h1>
        </div>
    );
}

export default CheckoutPage;
