import React from 'react';

const UserProfilePage = () => {
    return (
        <div>
            <h1>User Profile Page</h1>
        </div>
    );
}

export default UserProfilePage;
